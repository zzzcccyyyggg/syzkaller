#ifndef RECORD_SHARED_VARIABLE_HPP
#define RECORD_SHARED_VARIABLE_HPP
#pragma once
#define TAINT_ANALYSIS 1

#include "llvm/IR/Module.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/DebugInfo.h"
#include "llvm/IR/Type.h"

#include "auxiliary.hpp"
#include "config.hpp"
#include "taint_analysis.hpp"

#include <vector>
#include <string>
#include <map>

/* -------- Extern Interface --------*/
void RecordSharedVariableAccess(llvm::Module *mod);

#endif // RECORD_SHARED_VARIABLE_HPP