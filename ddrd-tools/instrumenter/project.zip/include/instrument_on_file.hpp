#ifndef INSTRUMENT_ON_FILE_HPP
#define INSTRUMENT_ON_FILE_HPP
#pragma once

#include <llvm/IR/Module.h>

#include "record_function.hpp"
#include "record_shared_variable.hpp"


/* -------- Extern Interface --------*/
void InstrumentOnFile(llvm::Module *mod, std::string lockfile, std::string trylockfile);

#endif // INSTRUMENT_ON_FILE_HPP