#ifndef CCWF_CONFIG_HPP
#define CCWF_CONFIG_HPP

#include <map>
#include <string>

#define INSERT_INFO_PATH "/home/zzzccc/CCWF/instrumenter/insert_info.txt"

#define IR_INSTRUCTIONS 0
#define FUNCTION_CALL 1


struct InsertInfo {
    int target_kind;         // 插桩目标类型：FUNCTION_CALL 或 IR_INSTRUCTIONS_TYPE
    int access_type;         // 访问类型：READ / WRITE
    int operand_index;       // 被插桩函数或指令中待记录的参数索引
    int insertion_offset;    // 插入点相对位置：从匹配指令向后偏移几条指令后插入
};

extern std::map<std::string, InsertInfo> insert_info_local_map;
#endif