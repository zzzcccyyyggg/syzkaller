#include "instrument_on_file.hpp"
void InstrumentOnFile(llvm::Module *mod,std::string lockfile, std::string trylockfile) {
    RecordFunctionEnterExit(mod);
    RecordSharedVariableAccess(mod);
}