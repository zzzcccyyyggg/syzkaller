#include "handle_file.hpp"

int main(int argc, char **argv) {
    HandleFile(argv[1], argv[2], argv[3]);
    return 0;
}