#include "record_shared_variable.hpp"
#include "config.hpp"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/Value.h"
#include "llvm/Support/raw_ostream.h"
// 唯一标志在IR指令在某个func中的位置
static int block_serial_number = 0;
static int instruction_serial_number = 0;

// 统计插桩次数
static int record_count = 0;

static unsigned int get_seriral_number_in_ir(int block_serial_number, int instruction_serial_number)
{
    // 高16位为basicblock序号，低16位位ir序号
    return ((block_serial_number & 0xffff) << 16) | (instruction_serial_number & 0xffff);
}

uint64_t computeFuncHash(const std::string& funcName, int ir_serial)
{
    std::string line_str = std::to_string(ir_serial);
    return BKDRHash((funcName + ":" + line_str).c_str(), 0);
}

// 声明外部函数 void rec_mem_access(const volatile void *addr, unsigned long var_name, int is_write, int file_line, int size)
static llvm::Function* DeclareMemRec(llvm::Module* mod)
{
    llvm::LLVMContext& context = mod->getContext();
    llvm::Type* VoidPtrTy = llvm::Type::getInt8PtrTy(context); // void* 类型
    llvm::Type* Int32Ty = llvm::Type::getInt32Ty(context); // int 类型
    // llvm::Type *CharPtrTy = llvm::Type::getInt8PtrTy(context); // char* 类型（实质上是 i8*）
    llvm::Type* int64Ty = llvm::Type::getInt64Ty(context); // int64 类型

    // 创建函数类型：void rec_mem_access(void*, char*, int, int)
    llvm::FunctionType* FuncTy = llvm::FunctionType::get(llvm::Type::getVoidTy(context), { VoidPtrTy, int64Ty, Int32Ty, Int32Ty, Int32Ty }, false);
    std::string func_name = "kccwf_rec_mem_access";
    llvm::Function* Func = mod->getFunction(func_name);
    if (!Func) {
        Func = llvm::Function::Create(FuncTy, llvm::Function::ExternalLinkage, func_name, mod);
        Func->setCallingConv(llvm::CallingConv::C);
        return Func;
    }

    return Func;
}

std::string getInstructionTypeAsString(llvm::Instruction* I)
{
    if (llvm::isa<llvm::StoreInst>(I)) {
        return "StoreInst";
    } else if (llvm::isa<llvm::LoadInst>(I)) {
        return "LoadInst";
    } else if (llvm::isa<llvm::CallInst>(I)) {
        return "CallInst";
    } else if (llvm::isa<llvm::AllocaInst>(I)) {
        return "AllocaInst";
    } else {
        return "UnkownType";
    }
}

void emitInstrumentationCall(
    llvm::IRBuilder<>& builder,
    llvm::Function* recFunc,
    llvm::Value* ptr,
    uint64_t func_hash,
    int is_write,
    int line,
    int size_bytes)
{
    llvm::LLVMContext& ctx = builder.getContext();
    llvm::Value* ptr_cast = builder.CreateBitCast(ptr, llvm::Type::getInt8PtrTy(ctx));
    llvm::Value* hash_val = llvm::ConstantInt::get(llvm::Type::getInt64Ty(ctx), func_hash);
    llvm::Value* type_val = builder.getInt32(is_write);
    llvm::Value* line_val = builder.getInt32(line);
    llvm::Value* size_val = builder.getInt32(size_bytes);
    builder.CreateCall(recFunc, { ptr_cast, hash_val, type_val, line_val, size_val });
}

static void InsertFunc(llvm::Function* recFunc, llvm::Module* mod)
{

    for (auto& F : *mod) {
        block_serial_number = 0;

        const llvm::DataLayout& DL = mod->getDataLayout();
        TaintAnalysis analyzer;
        analyzer.analyzeFunctionFlowSensitive(F);
        const std::set<Instruction*>& accessSet = analyzer.getAccessSet();

        if (F.getName().str().find("asan") != std::string::npos || F.getName().str().find("llvm") != std::string::npos || F.getName().str().find("kcsan") != std::string::npos) {
            continue;
        }
        for (auto& BB : F) {
            instruction_serial_number = 0;
            block_serial_number++;
            for (auto& I : BB) {
                instruction_serial_number++;
                if (auto* inst = llvm::dyn_cast<llvm::Instruction>(&I)) {
                    std::string instruction_type = getInstructionTypeAsString(inst);
                    if (llvm::CallInst* callInst = llvm::dyn_cast<llvm::CallInst>(inst)) {
                        if (auto* callee = callInst->getCalledFunction()) {
                            // llvm::outs() << "B";
                            auto it = insert_info_local_map.find(callee->getName().str());
                            if (it != insert_info_local_map.end() && it->second.target_kind == FUNCTION_CALL) {
                                llvm::Value* ptr = callInst->getArgOperand(it->second.operand_index);
                                llvm::Instruction* next_inst = (llvm::Instruction*)callInst;
                                for (int i = 0; i < it->second.insertion_offset; i++) {
                                    next_inst = next_inst->getNextNode();
                                }
                                llvm::IRBuilder<> builder(next_inst);
                                if (!ptr)
                                    continue;
                                uint64_t func_hash = computeFuncHash(F.getName().str(), get_seriral_number_in_ir(block_serial_number, instruction_serial_number));
                                emitInstrumentationCall(builder, recFunc, ptr, func_hash, it->second.insertion_offset, get_seriral_number_in_ir(block_serial_number, instruction_serial_number), 1);
                                record_count++;
                                continue;
                            }
                        }
                    }
                    auto it = insert_info_local_map.find(instruction_type);
                    if (it != insert_info_local_map.end() && it->second.target_kind == IR_INSTRUCTIONS) {
                        // llvm::outs() << "A";
                        if (TAINT_ANALYSIS && !accessSet.count(inst))
                            continue;
                        llvm::Instruction* next_inst = inst;
                        for (int i = 0; i < insert_info_local_map[instruction_type].insertion_offset; i++) {
                            next_inst = next_inst->getNextNode();
                        }
                        llvm::IRBuilder<> builder(next_inst);
                        llvm::Value* ptr = inst->getOperand(it->second.operand_index);
                        llvm::Type* orig_ty = getLoadStoreType(inst);
                        int size = DL.getTypeStoreSizeInBits(orig_ty) / 8;
                        uint64_t func_hash = computeFuncHash(F.getName().str(), get_seriral_number_in_ir(block_serial_number, instruction_serial_number));
                        emitInstrumentationCall(builder, recFunc, ptr, func_hash, it->second.insertion_offset, get_seriral_number_in_ir(block_serial_number, instruction_serial_number), size);
                        record_count++;
                    }
                }
            }
        }
    }
    std::cout << "record count: " << record_count << "\n"
              << std::endl;
}

static void read_insert_info(string path)
{
    FILE* fp = fopen(path.c_str(), "r");
    if (!fp) {
        cout << "*** [ERROR] Fail to open free func file ***" << endl;
        return;
    }
    char name[100];
    int arg_pos = 0;
    int insert_pos = 0;
    int type = 0;
    int inserted_type = 0;
    while (fscanf(fp, "%s%d%d%d%d", name, &type, &inserted_type, &arg_pos, &insert_pos) != EOF) {
        InsertInfo new_insert_info {
            .target_kind = type,
            .access_type = inserted_type,
            .operand_index = arg_pos,
            .insertion_offset = insert_pos
        };
        insert_info_local_map[name] = new_insert_info;
    }
    fclose(fp);
}
std::map<std::string, InsertInfo> insert_info_local_map;

void RecordSharedVariableAccess(llvm::Module* mod)
{
    read_insert_info(INSERT_INFO_PATH);
    llvm::Function* func_mem = DeclareMemRec(mod);
    InsertFunc(func_mem, mod);
}