#include "handle_file.hpp"
#include "auxiliary.hpp"

void WriteModuleToFile(llvm::Module *mod, std::string file_out) {
        std::error_code ec;
        llvm::raw_fd_ostream out(file_out, ec);
        mod->print(out, nullptr);
        out.close();
}

void HandleFile(std::string filein, std::string lockfile, std::string trylockfile) {
    if (filein.empty()) {
        std::cout << "Filename is required" << std::endl;
        exit(1);
    }

    llvm::LLVMContext Context;
    llvm::SMDiagnostic Err;
    std::unique_ptr<llvm::Module> M = llvm::parseIRFile(filein, Err, Context);
    if (!M) {
        Err.print(filein.c_str(), llvm::errs());
        exit(1);
    }

    InstrumentOnFile(M.get(), lockfile, trylockfile);

    if (verifyModule(*M, &llvm::errs())) {
        llvm::errs() << "Error: Module failed verification\n";
        exit(1);
    }

    llvm::StringRef in_file_name = filein;
    std::string fileout;
    fileout = (in_file_name.endswith(".ll") ? in_file_name.drop_back(3) : in_file_name).str();
    fileout += ".instrumented.ll";

    WriteModuleToFile(M.get(), fileout);
    PrintSuccess("Successfully instrument " + fileout );
}