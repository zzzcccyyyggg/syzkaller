# Conzzer MRP 10ms 8-module plot bundle

Created: 2026-05-27 09:52:17.676872

This bundle contains the final valid data for the paper experiment:

- Race threshold: 10ms (`MRP_RACE_THRESHOLD_NS=10000000`)
- Guest collector interval: 1ms (`MRP_GUEST_COLLECTOR_INTERVAL_MS=1`)
- UAF collection: disabled (`MRP_COLLECT_UAF=0`)
- FS modules (`f2fs`, `jfs`, `btrfs`, `xfs`): iozone-only, `iozone -t 4`
- Corpus modules (`bt-stack`, `floppy`, `ptmx`, `dsp`): corpus workload, `syz-execprog -procs=4`

## Files

- `final_results.csv`: final per-module summary for bar plots/tables.
- `timeseries_all.csv`: all valid per-sample rows merged across the 8 modules.
- `timeseries_1min.csv`: one row per module per elapsed minute, useful for plotting curves.
- `module_sources.csv`: source run and CSV used for each module.
- `raw_csv/*.csv`: copied raw collector CSV for each final-valid module.
- `metadata/`: run envs, master logs, and final summaries from the source runs.
- `metadata.json`: machine-readable provenance and totals.

## Final Results

| module | workload | capped_mrp | raw_mrp | varname_pairs |
| --- | --- | ---: | ---: | ---: |
| f2fs | iozone-only | 186 | 186 | 87 |
| jfs | iozone-only | 243 | 250 | 95 |
| btrfs | iozone-only | 262 | 262 | 114 |
| xfs | iozone-only | 310 | 337 | 187 |
| bt-stack | corpus | 237 | 239 | 80 |
| floppy | corpus | 138 | 138 | 73 |
| ptmx | corpus | 8 | 8 | 8 |
| dsp | corpus | 17 | 17 | 11 |

Totals: capped_mrp=1401, raw_mrp=1437, varname_pairs=655.

Important: corpus-module data in the original selected_8 run used earlier workload settings and is intentionally excluded from this final bundle.
